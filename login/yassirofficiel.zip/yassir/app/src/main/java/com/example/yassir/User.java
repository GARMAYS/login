package com.example.yassir;

public class User {
    public String nom,email,cin;
    public User(){

    }

    public User(String nom, String email, String cin) {
        this.nom = nom;
        this.email = email;
        this.cin = cin;
    }
}
